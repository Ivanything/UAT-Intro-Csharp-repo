﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoonBaseAlpha
{
    public partial class Outside : Form
    {
        public Outside()
        {
            InitializeComponent();
        }

        private void EnterMoonBase_Click(object sender, EventArgs e)
        {
            MoonBase moonbase = new MoonBase();
            this.Hide();
            moonbase.Show();
        }
    }
}
