﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoonBaseAlpha
{
    public partial class MoonBase : Form
    {
        public bool hasSpaceSuit = false;
        public MoonBase()
        {
            InitializeComponent();
        }

        private void EquipSuit_Click(object sender, EventArgs e)
        {
            EquipSuit.Visible = false;
            hasSpaceSuit = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (hasSpaceSuit)
            {
                Outside surface = new Outside();
                surface.Show();
            }
            else
            {
                Heaven heben = new Heaven();
                heben.Show();
            }
            this.Hide();
        }
    }
}
