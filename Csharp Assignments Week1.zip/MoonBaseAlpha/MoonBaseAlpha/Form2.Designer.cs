﻿
namespace MoonBaseAlpha
{
    partial class Outside
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnterMoonBase = new System.Windows.Forms.Button();
            this.LBoutsideName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // EnterMoonBase
            // 
            this.EnterMoonBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterMoonBase.Location = new System.Drawing.Point(678, 733);
            this.EnterMoonBase.Name = "EnterMoonBase";
            this.EnterMoonBase.Size = new System.Drawing.Size(588, 213);
            this.EnterMoonBase.TabIndex = 0;
            this.EnterMoonBase.Text = "Back";
            this.EnterMoonBase.UseVisualStyleBackColor = true;
            this.EnterMoonBase.Click += new System.EventHandler(this.EnterMoonBase_Click);
            // 
            // LBoutsideName
            // 
            this.LBoutsideName.AutoSize = true;
            this.LBoutsideName.Font = new System.Drawing.Font("Microsoft Sans Serif", 80F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBoutsideName.Location = new System.Drawing.Point(493, 63);
            this.LBoutsideName.Name = "LBoutsideName";
            this.LBoutsideName.Size = new System.Drawing.Size(991, 120);
            this.LBoutsideName.TabIndex = 1;
            this.LBoutsideName.Text = "Moon Base Exterior";
            // 
            // Outside
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MoonBaseAlpha.Properties.Resources.moonbaseExterior;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.LBoutsideName);
            this.Controls.Add(this.EnterMoonBase);
            this.Name = "Outside";
            this.Text = "Moon Surface";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EnterMoonBase;
        private System.Windows.Forms.Label LBoutsideName;
    }
}