﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace First_Csharp_Forms_Application
{
    public partial class MathForm : Form
    {
        public static int correctnessCounter = 0;
        private int operation = 0;
        private int num1 = 1;
        private int num2 = 1;
        public static Random generator = new Random();
        public MathForm()
        {
            InitializeComponent();
        }

        private void BTNenter_Click(object sender, EventArgs e)
        {
            CheckIfAnswerIsCorrect();
            operation = generator.Next() % 3;
            num1 = generator.Next() % 10;
            num2 = generator.Next() % 10;
            DisplayEquation();
        }

        void CheckIfAnswerIsCorrect()
        {
            if (!int.TryParse(TBinput.Text, out int result))
            {
                correctnessCounter = 0;
                LBLcounter.Text = correctnessCounter + "";
                TBinput.Text = "";
                return;
            }

            if (getAnswerToMath() == result)
            {
                correctnessCounter++;
            }
            else
            {
                correctnessCounter = 0;
            }

            LBLcounter.Text = correctnessCounter + "";
            TBinput.Text = "";
        }

        int getAnswerToMath()
        {
            switch (operation)
            {
                case 0:
                    return num1 + num2;
                case 1:
                    return num1 - num2;
                case 2:
                    return num1 * num2;
            }
            return 0;
        }

        void DisplayEquation()
        {
            string display = num1 + "";
            switch (operation)
            {
                case 0:
                    display += " + ";
                    break;
                case 1:
                    display += " - ";
                    break;
                case 2:
                    display += " x ";
                    break;
            }
            display += num2 + "";
            LBLequation.Text = display;
        }
    }
}
