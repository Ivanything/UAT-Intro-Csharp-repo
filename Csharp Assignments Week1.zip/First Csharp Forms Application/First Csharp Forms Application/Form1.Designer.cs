﻿
namespace First_Csharp_Forms_Application
{
    partial class MathForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MathForm));
            this.BTNenter = new System.Windows.Forms.Button();
            this.TBinput = new System.Windows.Forms.TextBox();
            this.LBLequation = new System.Windows.Forms.Label();
            this.LBLcounter = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BTNenter
            // 
            this.BTNenter.BackColor = System.Drawing.Color.OrangeRed;
            this.BTNenter.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNenter.Location = new System.Drawing.Point(61, 247);
            this.BTNenter.Name = "BTNenter";
            this.BTNenter.Size = new System.Drawing.Size(184, 72);
            this.BTNenter.TabIndex = 0;
            this.BTNenter.Text = "ENTER";
            this.BTNenter.UseVisualStyleBackColor = false;
            this.BTNenter.Click += new System.EventHandler(this.BTNenter_Click);
            // 
            // TBinput
            // 
            this.TBinput.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBinput.Location = new System.Drawing.Point(59, 190);
            this.TBinput.Name = "TBinput";
            this.TBinput.Size = new System.Drawing.Size(186, 38);
            this.TBinput.TabIndex = 1;
            // 
            // LBLequation
            // 
            this.LBLequation.AutoSize = true;
            this.LBLequation.BackColor = System.Drawing.Color.White;
            this.LBLequation.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLequation.Location = new System.Drawing.Point(76, 94);
            this.LBLequation.Name = "LBLequation";
            this.LBLequation.Size = new System.Drawing.Size(147, 63);
            this.LBLequation.TabIndex = 2;
            this.LBLequation.Text = "1 + 1";
            // 
            // LBLcounter
            // 
            this.LBLcounter.AutoSize = true;
            this.LBLcounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBLcounter.Location = new System.Drawing.Point(287, 9);
            this.LBLcounter.Name = "LBLcounter";
            this.LBLcounter.Size = new System.Drawing.Size(83, 91);
            this.LBLcounter.TabIndex = 3;
            this.LBLcounter.Text = "0";
            this.LBLcounter.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MathForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(645, 359);
            this.Controls.Add(this.LBLcounter);
            this.Controls.Add(this.LBLequation);
            this.Controls.Add(this.TBinput);
            this.Controls.Add(this.BTNenter);
            this.Name = "MathForm";
            this.Text = "Math";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNenter;
        private System.Windows.Forms.TextBox TBinput;
        private System.Windows.Forms.Label LBLequation;
        private System.Windows.Forms.Label LBLcounter;
    }
}

